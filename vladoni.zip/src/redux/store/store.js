import { configureStore } from "@reduxjs/toolkit";
import cartItemReducer from "../slices/cartItemSlice";


const store=configureStore({
    reducer:{
        cartItem:cartItemReducer
    }
})


export default store