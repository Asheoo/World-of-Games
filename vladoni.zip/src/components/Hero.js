import React, { Component, useEffect, useState } from 'react';
import Imgs from './Imgs';
import Menu_wrapper from './Menu_wrapper';
import NavigationManual from './NavigationManual';
import PageOne from './PageOne';
import '../css/Hero.css';


function Hero() {
	

	const [games, setGames] = useState([]);
	const shuffle = (arr) => [...arr].sort(() => Math.random() - 0.5);
	// const shuffleGames=shuffle(games)
	useEffect(() => {
		fetch('https://raw.githubusercontent.com/Asheoo/games.json/main/games.json')
			.then((res) => res.json())
			.then((result) => {
				setGames(shuffle(result));
			});
	}, []);

	return (
		<>
			<div className="hero-bg">
				<Imgs games={games}></Imgs>
				<Menu_wrapper></Menu_wrapper>
				<NavigationManual></NavigationManual>
			</div>
			<PageOne games={games}></PageOne>
		</>
	);
}

export default Hero;
