import React, { Component } from 'react';
import { useSelector } from 'react-redux';
import CartItem from './CartItem';
import Menu_wrapper from './Menu_wrapper';
import '../css/Shop.css';
import { NavLink } from 'react-router-dom';
import Summary from './Summary';
import { changeExist } from '../redux/slices/cartItemSlice';

function ShopingCart() {
	
	const cartItems = useSelector((state) => state?.cartItem.value);
	let numberOfItems=0
	// const uniqueIds=[]
	// const filterDuplicates=cartItems.filter(element=>{
	// 	const isDuplicate=uniqueIds.includes(element.id);

	// 	if (!isDuplicate){
	// 		uniqueIds.push(element.id)
	// 		return true
	// 	}

		
	// 	return false

	// })
	const allCartItems =cartItems.map((item, index) => {
		numberOfItems=index+1
		return (
			<div key={item.id}>
				<CartItem game={item} index={index}></CartItem>
			</div>
		);
	});
	
	return (
		<div className="shop-bg">
			<div className="shoping-cart">
				<div className="cart-wide">
					<div className="shop-header">
						<h2>Shoping Cart</h2>
						<h2>{numberOfItems} {numberOfItems<=1 ? "item" : "items"}</h2>
					</div>
					<div className="line"></div>
					<ul className="cart-ul">
						<li>product details</li>
						<li>discount</li>
						<li>price</li>
						<li>total</li>
					</ul>
					{allCartItems}
					<NavLink to={-1} className='continue-shoping'>
						<i className="fa-solid fa-angle-left"></i>
						<h2>Countinue shoping</h2>
					</NavLink>
				</div>
				<div className="summary">
				

					<Summary numberOfItems={numberOfItems} cartItems={cartItems}></Summary>
				</div>
			</div>
		</div>
	);
}

export default ShopingCart;
