import React, { Component } from 'react';


function AllComputer(){
return(
    <h1>All Computer</h1>
)
}

export default AllComputer