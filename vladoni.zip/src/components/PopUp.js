import React, { Component } from 'react';
import "../css/PopUp.css"


function PopUp({disabled}){

    const show=disabled ? "show" : "none"
    console.log(disabled);
    return(
        <div className='popup' style={{display:`${disabled ? "show" : "none"}`}}>
            <h3>Proizvod se vec nalazi u korpi</h3>
            <button>OK</button>
        </div>
    )
}


export default PopUp