import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import '../css/Computer.css';
import AllComputer from './AllComputer';

function PageTwo() {
	return (
		<div className="computer-container">
			<div className="category-nav">
				<ul className="category">
					<li>
						<NavLink to="/pc/">All</NavLink>
					</li>
					<li>
						<NavLink to="/pc/new">New</NavLink>
					</li>
					<li>
						<NavLink to="/pc/sale">Sale</NavLink>
					</li>
					<li>
						<NavLink to="/pc/free">Free</NavLink>
					</li>
				</ul>
			</div>
			<AllComputer></AllComputer>
		</div>
	);
}

export default PageTwo;
