import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';

function Menu_wrapper() {
	return (
		<div className="menu-wrapper">
			<header>
				<h1>World of Games</h1>
			</header>
			<div className="menu">
				<ul>
					<li>
						<NavLink to="/" end>
							Home
						</NavLink>
					</li>
					<li>
						<NavLink to="/pc">PC</NavLink>
					</li>
					<li>
						<NavLink to="/playstation">PlayStation</NavLink>
					</li>
					<li>
						<NavLink to="/xbox">Xbox</NavLink>
					</li>
				</ul>
			</div>
			<div className="right-menu">
				<div className="search-icon">
					<form action="">
						<input className="search" type="search" name="" id="search" placeholder="Search..." />
					</form>
					<i className="fa-solid fa-magnifying-glass"></i>
				</div>
				<NavLink to="/cart">
					<i className="fa-solid fa-cart-shopping"></i>
				</NavLink>
				<div className="login">
					<ul>
						<li>Login</li>
						<li>Register</li>
					</ul>
				</div>
			</div>
		</div>
	);
}

export default Menu_wrapper;
