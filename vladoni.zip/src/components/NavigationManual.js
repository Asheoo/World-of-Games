import React, { Component } from 'react';

function NavigationManual() {
	return (
		<div className="navigation-manual">
			<label htmlFor="radio1" className="manual-btn"></label>
			<label htmlFor="radio2" className="manual-btn"></label>
			<label htmlFor="radio3" className="manual-btn"></label>
		</div>
	);
}

export default NavigationManual;
