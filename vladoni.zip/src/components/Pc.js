import React, { Component } from 'react';
import Menu_wrapper from './Menu_wrapper';
import PageTwo from './PageTwo';

function Pc() {
	return (
		<>
			<Menu_wrapper></Menu_wrapper>
			<PageTwo></PageTwo>
		</>
	);
}

export default Pc;
