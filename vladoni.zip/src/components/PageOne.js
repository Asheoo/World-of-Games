import React, { Component,useState} from 'react';
import NewGames from './NewGames';
import Recommended from './Recommended';
import PopUp from './PopUp';
import { useSelector } from 'react-redux';
import useDidMountEffect from '../customHooks/useDidMountEffect';
import { useEffect } from 'react';



function PageOne({games}){
    const [showPopup, setShowPopup]=useState()
    const stayOnPage = useSelector((state) => state?.cartItem.stayOnPage);
    useEffect(() => {
       
            setShowPopup(true)
        
		console.log('Ostani na stranici',showPopup);
	}, [stayOnPage===false]);

    // const [games,setGames]=useState([]);

    // useEffect(()=>{
    //     fetch('https://raw.githubusercontent.com/Asheoo/games.json/main/games.json')
    //     .then(res=>res.json())
    //     .then(result=>{
    //         setGames(result)
    //     })
    // },[])
    return(
        <div className="container">
            <PopUp disabled={showPopup}></PopUp>
            <Recommended games={games}></Recommended>
            <NewGames games={games}></NewGames>
        </div>
    )

}

export default PageOne