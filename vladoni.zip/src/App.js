import React, { Component, useEffect, useState } from 'react';
import Hero from './components/Hero';
import { useSelector } from 'react-redux';
import { BrowserRouter, Route, Routes, Navigate, useNavigate } from 'react-router-dom';
import Pc from './components/Pc';
import ShopingCart from './components/ShopingCart';
import useDidMountEffect from './customHooks/useDidMountEffect';

function App() {
	const navigate = useNavigate();
	const exist = useSelector((state) => state?.cartItem.exist);
	// const stayOnPage = useSelector((state) => state?.cartItem.stayOnPage);

	useEffect(() => {
		const navigateToCart = () => {
			navigate('/cart');
		};

		navigateToCart();

		// console.log(exist);
	}, [exist]);

	// useDidMountEffect(() => {
	// 	console.log('Ostani na stranici');
	// }, [stayOnPage == false]);

	const cartItems = useSelector((state) => state?.cartItem.value);

	return (
		<Routes>
			<Route path="/" exact element={<Hero></Hero>}></Route>
			<Route path="/pc" element={<Pc></Pc>}></Route>
			<Route
				path="/cart"
				element={cartItems.length < 1 ? <Navigate to="/" /> : <ShopingCart></ShopingCart>}
			></Route>
			<Route path="*" element={<Navigate to="/" replace />}></Route>
		</Routes>
	);
}

export default App;
